
from flask import Flask, render_template, request, redirect, url_for, session
from auth.routes import auth_bp
from resumes.upload import resumes_bp
from ai.query_engine import ai_bp
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['UPLOAD_FOLDER'] = 'uploads'

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'auth.login'

from auth.models import User
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

app.register_blueprint(auth_bp)
app.register_blueprint(resumes_bp)
app.register_blueprint(ai_bp)

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    db.create_all()
    app.run(debug=True)
