
from flask import Blueprint, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
from app import db
from resumes.parser import parse_resume
import os, json

resumes_bp = Blueprint('resumes', __name__, url_prefix='/resumes')

@resumes_bp.route('/upload', methods=['GET', 'POST'])
def upload_resume():
    if request.method == 'POST':
        file = request.files['resume']
        filename = secure_filename(file.filename)
        filepath = os.path.join('uploads', filename)
        file.save(filepath)

        data = parse_resume(filepath)
        with open('resumes.json', 'a') as f:
            f.write(json.dumps(data) + '\n')

        return render_template('upload_success.html', data=data)
    return render_template('upload.html')
