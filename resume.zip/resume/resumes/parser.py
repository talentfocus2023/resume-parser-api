
import openai, os
openai.api_key = os.getenv("OPENAI_API_KEY")

def parse_resume(text_file):
    with open(text_file, 'rb') as f:
        text = f.read().decode(errors='ignore')

    prompt = f"""
Extract this resume into JSON:
- name
- email
- phone
- skills
- experience
- education
- certifications
{text}
"""

    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content
