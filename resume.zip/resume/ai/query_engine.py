
from flask import Blueprint, render_template, request
import openai, os, json

ai_bp = Blueprint('ai', __name__, url_prefix='/ai')

@ai_bp.route('/search', methods=['GET', 'POST'])
def search():
    result = ""
    if request.method == 'POST':
        query = request.form['query']
        with open('resumes.json') as f:
            db = [json.loads(line) for line in f]

        prompt = f"From this data {db}, find candidates matching: {query}"
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}]
        )
        result = response.choices[0].message.content
    return render_template('search.html', result=result)
